﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sofer_Exceptional
{
	class GlobalVariables
	{
		public static int idUser;
		public static bool testPassed;
		public static int questionsTrue;
		public static int questionsFalse;
	}
}
