﻿
namespace Sofer_Exceptional
{
	partial class ucTest
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucTest));
			Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
			Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
			Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
			Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
			Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
			Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
			Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
			Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
			Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
			this.pnlTestTop = new System.Windows.Forms.Panel();
			this.txtQuestionsTrueNumber = new System.Windows.Forms.Label();
			this.txtQuestionsTrueText = new System.Windows.Forms.Label();
			this.txtQuestionsFalseNumber = new System.Windows.Forms.Label();
			this.txtQuestionsFalseText = new System.Windows.Forms.Label();
			this.txtQuestionsTotalNumber = new System.Windows.Forms.Label();
			this.txtQuestionsTotalText = new System.Windows.Forms.Label();
			this.txtQuestionsLeftNumber = new System.Windows.Forms.Label();
			this.txtQuestionsLeftText = new System.Windows.Forms.Label();
			this.lblTimer = new System.Windows.Forms.Label();
			this.pnlTestBot = new System.Windows.Forms.Panel();
			this.btnQueueQuestion = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
			this.btnEraseAnswer = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
			this.btnSendAnswer = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
			this.btnAnswerA = new Bunifu.Framework.UI.BunifuFlatButton();
			this.txtQuestion = new System.Windows.Forms.Label();
			this.lblAnswerA = new System.Windows.Forms.Label();
			this.lblAnswerB = new System.Windows.Forms.Label();
			this.btnAnswerB = new Bunifu.Framework.UI.BunifuFlatButton();
			this.lblAnswerC = new System.Windows.Forms.Label();
			this.btnAnswerC = new Bunifu.Framework.UI.BunifuFlatButton();
			this.pnlTestTop.SuspendLayout();
			this.pnlTestBot.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlTestTop
			// 
			this.pnlTestTop.BackColor = System.Drawing.Color.White;
			this.pnlTestTop.Controls.Add(this.txtQuestionsTrueNumber);
			this.pnlTestTop.Controls.Add(this.txtQuestionsTrueText);
			this.pnlTestTop.Controls.Add(this.txtQuestionsFalseNumber);
			this.pnlTestTop.Controls.Add(this.txtQuestionsFalseText);
			this.pnlTestTop.Controls.Add(this.txtQuestionsTotalNumber);
			this.pnlTestTop.Controls.Add(this.txtQuestionsTotalText);
			this.pnlTestTop.Controls.Add(this.txtQuestionsLeftNumber);
			this.pnlTestTop.Controls.Add(this.txtQuestionsLeftText);
			this.pnlTestTop.Controls.Add(this.lblTimer);
			this.pnlTestTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlTestTop.Location = new System.Drawing.Point(0, 0);
			this.pnlTestTop.Name = "pnlTestTop";
			this.pnlTestTop.Size = new System.Drawing.Size(1181, 75);
			this.pnlTestTop.TabIndex = 0;
			// 
			// txtQuestionsTrueNumber
			// 
			this.txtQuestionsTrueNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.txtQuestionsTrueNumber.AutoSize = true;
			this.txtQuestionsTrueNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtQuestionsTrueNumber.ForeColor = System.Drawing.Color.LimeGreen;
			this.txtQuestionsTrueNumber.Location = new System.Drawing.Point(735, 11);
			this.txtQuestionsTrueNumber.Name = "txtQuestionsTrueNumber";
			this.txtQuestionsTrueNumber.Size = new System.Drawing.Size(36, 25);
			this.txtQuestionsTrueNumber.TabIndex = 19;
			this.txtQuestionsTrueNumber.Text = "26";
			// 
			// txtQuestionsTrueText
			// 
			this.txtQuestionsTrueText.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.txtQuestionsTrueText.AutoSize = true;
			this.txtQuestionsTrueText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtQuestionsTrueText.Location = new System.Drawing.Point(680, 36);
			this.txtQuestionsTrueText.Name = "txtQuestionsTrueText";
			this.txtQuestionsTrueText.Size = new System.Drawing.Size(147, 20);
			this.txtQuestionsTrueText.TabIndex = 18;
			this.txtQuestionsTrueText.Text = "Raspunsuri corecte";
			// 
			// txtQuestionsFalseNumber
			// 
			this.txtQuestionsFalseNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.txtQuestionsFalseNumber.AutoSize = true;
			this.txtQuestionsFalseNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtQuestionsFalseNumber.ForeColor = System.Drawing.Color.Crimson;
			this.txtQuestionsFalseNumber.Location = new System.Drawing.Point(892, 11);
			this.txtQuestionsFalseNumber.Name = "txtQuestionsFalseNumber";
			this.txtQuestionsFalseNumber.Size = new System.Drawing.Size(36, 25);
			this.txtQuestionsFalseNumber.TabIndex = 17;
			this.txtQuestionsFalseNumber.Text = "26";
			// 
			// txtQuestionsFalseText
			// 
			this.txtQuestionsFalseText.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.txtQuestionsFalseText.AutoSize = true;
			this.txtQuestionsFalseText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtQuestionsFalseText.Location = new System.Drawing.Point(841, 36);
			this.txtQuestionsFalseText.Name = "txtQuestionsFalseText";
			this.txtQuestionsFalseText.Size = new System.Drawing.Size(142, 20);
			this.txtQuestionsFalseText.TabIndex = 16;
			this.txtQuestionsFalseText.Text = "Raspunsuri gresite";
			// 
			// txtQuestionsTotalNumber
			// 
			this.txtQuestionsTotalNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.txtQuestionsTotalNumber.AutoSize = true;
			this.txtQuestionsTotalNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtQuestionsTotalNumber.Location = new System.Drawing.Point(282, 11);
			this.txtQuestionsTotalNumber.Name = "txtQuestionsTotalNumber";
			this.txtQuestionsTotalNumber.Size = new System.Drawing.Size(36, 25);
			this.txtQuestionsTotalNumber.TabIndex = 15;
			this.txtQuestionsTotalNumber.Text = "26";
			// 
			// txtQuestionsTotalText
			// 
			this.txtQuestionsTotalText.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.txtQuestionsTotalText.AutoSize = true;
			this.txtQuestionsTotalText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtQuestionsTotalText.Location = new System.Drawing.Point(242, 36);
			this.txtQuestionsTotalText.Name = "txtQuestionsTotalText";
			this.txtQuestionsTotalText.Size = new System.Drawing.Size(116, 20);
			this.txtQuestionsTotalText.TabIndex = 14;
			this.txtQuestionsTotalText.Text = "Intrebari initiale";
			// 
			// txtQuestionsLeftNumber
			// 
			this.txtQuestionsLeftNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.txtQuestionsLeftNumber.AutoSize = true;
			this.txtQuestionsLeftNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtQuestionsLeftNumber.Location = new System.Drawing.Point(431, 11);
			this.txtQuestionsLeftNumber.Name = "txtQuestionsLeftNumber";
			this.txtQuestionsLeftNumber.Size = new System.Drawing.Size(36, 25);
			this.txtQuestionsLeftNumber.TabIndex = 13;
			this.txtQuestionsLeftNumber.Text = "26";
			// 
			// txtQuestionsLeftText
			// 
			this.txtQuestionsLeftText.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.txtQuestionsLeftText.AutoSize = true;
			this.txtQuestionsLeftText.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtQuestionsLeftText.Location = new System.Drawing.Point(388, 36);
			this.txtQuestionsLeftText.Name = "txtQuestionsLeftText";
			this.txtQuestionsLeftText.Size = new System.Drawing.Size(125, 20);
			this.txtQuestionsLeftText.TabIndex = 12;
			this.txtQuestionsLeftText.Text = "Intrebari ramase";
			// 
			// lblTimer
			// 
			this.lblTimer.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblTimer.AutoSize = true;
			this.lblTimer.BackColor = System.Drawing.Color.White;
			this.lblTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTimer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
			this.lblTimer.Location = new System.Drawing.Point(536, 11);
			this.lblTimer.Name = "lblTimer";
			this.lblTimer.Size = new System.Drawing.Size(119, 46);
			this.lblTimer.TabIndex = 0;
			this.lblTimer.Text = "30:00";
			this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlTestBot
			// 
			this.pnlTestBot.BackColor = System.Drawing.Color.White;
			this.pnlTestBot.Controls.Add(this.btnQueueQuestion);
			this.pnlTestBot.Controls.Add(this.btnEraseAnswer);
			this.pnlTestBot.Controls.Add(this.btnSendAnswer);
			this.pnlTestBot.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.pnlTestBot.Location = new System.Drawing.Point(0, 603);
			this.pnlTestBot.Name = "pnlTestBot";
			this.pnlTestBot.Size = new System.Drawing.Size(1181, 102);
			this.pnlTestBot.TabIndex = 1;
			// 
			// btnQueueQuestion
			// 
			this.btnQueueQuestion.AllowToggling = false;
			this.btnQueueQuestion.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btnQueueQuestion.AnimationSpeed = 200;
			this.btnQueueQuestion.AutoGenerateColors = false;
			this.btnQueueQuestion.BackColor = System.Drawing.Color.Transparent;
			this.btnQueueQuestion.BackColor1 = System.Drawing.Color.CornflowerBlue;
			this.btnQueueQuestion.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnQueueQuestion.BackgroundImage")));
			this.btnQueueQuestion.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
			this.btnQueueQuestion.ButtonText = "Raspunde mai tarziu";
			this.btnQueueQuestion.ButtonTextMarginLeft = 0;
			this.btnQueueQuestion.ColorContrastOnClick = 45;
			this.btnQueueQuestion.ColorContrastOnHover = 45;
			this.btnQueueQuestion.Cursor = System.Windows.Forms.Cursors.Hand;
			borderEdges1.BottomLeft = true;
			borderEdges1.BottomRight = true;
			borderEdges1.TopLeft = true;
			borderEdges1.TopRight = true;
			this.btnQueueQuestion.CustomizableEdges = borderEdges1;
			this.btnQueueQuestion.DialogResult = System.Windows.Forms.DialogResult.None;
			this.btnQueueQuestion.DisabledBorderColor = System.Drawing.Color.Empty;
			this.btnQueueQuestion.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
			this.btnQueueQuestion.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
			this.btnQueueQuestion.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
			this.btnQueueQuestion.Font = new System.Drawing.Font("Segoe UI Semibold", 13F);
			this.btnQueueQuestion.ForeColor = System.Drawing.Color.White;
			this.btnQueueQuestion.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
			this.btnQueueQuestion.IconMarginLeft = 11;
			this.btnQueueQuestion.IconPadding = 10;
			this.btnQueueQuestion.IconRightCursor = System.Windows.Forms.Cursors.Hand;
			this.btnQueueQuestion.IdleBorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnQueueQuestion.IdleBorderRadius = 3;
			this.btnQueueQuestion.IdleBorderThickness = 1;
			this.btnQueueQuestion.IdleFillColor = System.Drawing.Color.CornflowerBlue;
			this.btnQueueQuestion.IdleIconLeftImage = null;
			this.btnQueueQuestion.IdleIconRightImage = null;
			this.btnQueueQuestion.IndicateFocus = false;
			this.btnQueueQuestion.Location = new System.Drawing.Point(199, 12);
			this.btnQueueQuestion.Margin = new System.Windows.Forms.Padding(12, 12, 24, 12);
			this.btnQueueQuestion.Name = "btnQueueQuestion";
			stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
			stateProperties1.BorderRadius = 3;
			stateProperties1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
			stateProperties1.BorderThickness = 1;
			stateProperties1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
			stateProperties1.ForeColor = System.Drawing.Color.White;
			stateProperties1.IconLeftImage = null;
			stateProperties1.IconRightImage = null;
			this.btnQueueQuestion.onHoverState = stateProperties1;
			stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
			stateProperties2.BorderRadius = 3;
			stateProperties2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
			stateProperties2.BorderThickness = 1;
			stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
			stateProperties2.ForeColor = System.Drawing.Color.White;
			stateProperties2.IconLeftImage = null;
			stateProperties2.IconRightImage = null;
			this.btnQueueQuestion.OnPressedState = stateProperties2;
			this.btnQueueQuestion.Size = new System.Drawing.Size(231, 78);
			this.btnQueueQuestion.TabIndex = 2;
			this.btnQueueQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.btnQueueQuestion.TextMarginLeft = 0;
			this.btnQueueQuestion.UseDefaultRadiusAndThickness = true;
			this.btnQueueQuestion.Click += new System.EventHandler(this.btnQueueQuestion_Click);
			// 
			// btnEraseAnswer
			// 
			this.btnEraseAnswer.AllowToggling = false;
			this.btnEraseAnswer.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btnEraseAnswer.AnimationSpeed = 200;
			this.btnEraseAnswer.AutoGenerateColors = false;
			this.btnEraseAnswer.BackColor = System.Drawing.Color.Transparent;
			this.btnEraseAnswer.BackColor1 = System.Drawing.Color.CornflowerBlue;
			this.btnEraseAnswer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEraseAnswer.BackgroundImage")));
			this.btnEraseAnswer.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
			this.btnEraseAnswer.ButtonText = "Modifica raspunsul";
			this.btnEraseAnswer.ButtonTextMarginLeft = 0;
			this.btnEraseAnswer.ColorContrastOnClick = 45;
			this.btnEraseAnswer.ColorContrastOnHover = 45;
			this.btnEraseAnswer.Cursor = System.Windows.Forms.Cursors.Hand;
			borderEdges2.BottomLeft = true;
			borderEdges2.BottomRight = true;
			borderEdges2.TopLeft = true;
			borderEdges2.TopRight = true;
			this.btnEraseAnswer.CustomizableEdges = borderEdges2;
			this.btnEraseAnswer.DialogResult = System.Windows.Forms.DialogResult.None;
			this.btnEraseAnswer.DisabledBorderColor = System.Drawing.Color.Empty;
			this.btnEraseAnswer.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
			this.btnEraseAnswer.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
			this.btnEraseAnswer.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
			this.btnEraseAnswer.Font = new System.Drawing.Font("Segoe UI Semibold", 13F);
			this.btnEraseAnswer.ForeColor = System.Drawing.Color.White;
			this.btnEraseAnswer.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
			this.btnEraseAnswer.IconMarginLeft = 11;
			this.btnEraseAnswer.IconPadding = 10;
			this.btnEraseAnswer.IconRightCursor = System.Windows.Forms.Cursors.Hand;
			this.btnEraseAnswer.IdleBorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnEraseAnswer.IdleBorderRadius = 3;
			this.btnEraseAnswer.IdleBorderThickness = 1;
			this.btnEraseAnswer.IdleFillColor = System.Drawing.Color.CornflowerBlue;
			this.btnEraseAnswer.IdleIconLeftImage = null;
			this.btnEraseAnswer.IdleIconRightImage = null;
			this.btnEraseAnswer.IndicateFocus = false;
			this.btnEraseAnswer.Location = new System.Drawing.Point(478, 12);
			this.btnEraseAnswer.Margin = new System.Windows.Forms.Padding(24, 12, 24, 12);
			this.btnEraseAnswer.Name = "btnEraseAnswer";
			stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
			stateProperties3.BorderRadius = 3;
			stateProperties3.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
			stateProperties3.BorderThickness = 1;
			stateProperties3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
			stateProperties3.ForeColor = System.Drawing.Color.White;
			stateProperties3.IconLeftImage = null;
			stateProperties3.IconRightImage = null;
			this.btnEraseAnswer.onHoverState = stateProperties3;
			stateProperties4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
			stateProperties4.BorderRadius = 3;
			stateProperties4.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
			stateProperties4.BorderThickness = 1;
			stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
			stateProperties4.ForeColor = System.Drawing.Color.White;
			stateProperties4.IconLeftImage = null;
			stateProperties4.IconRightImage = null;
			this.btnEraseAnswer.OnPressedState = stateProperties4;
			this.btnEraseAnswer.Size = new System.Drawing.Size(231, 78);
			this.btnEraseAnswer.TabIndex = 1;
			this.btnEraseAnswer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.btnEraseAnswer.TextMarginLeft = 0;
			this.btnEraseAnswer.UseDefaultRadiusAndThickness = true;
			this.btnEraseAnswer.Click += new System.EventHandler(this.btnEraseAnswer_Click);
			// 
			// btnSendAnswer
			// 
			this.btnSendAnswer.AllowToggling = false;
			this.btnSendAnswer.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btnSendAnswer.AnimationSpeed = 200;
			this.btnSendAnswer.AutoGenerateColors = false;
			this.btnSendAnswer.BackColor = System.Drawing.Color.Transparent;
			this.btnSendAnswer.BackColor1 = System.Drawing.Color.CornflowerBlue;
			this.btnSendAnswer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSendAnswer.BackgroundImage")));
			this.btnSendAnswer.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
			this.btnSendAnswer.ButtonText = "Trimite raspunsul";
			this.btnSendAnswer.ButtonTextMarginLeft = 0;
			this.btnSendAnswer.ColorContrastOnClick = 45;
			this.btnSendAnswer.ColorContrastOnHover = 45;
			this.btnSendAnswer.Cursor = System.Windows.Forms.Cursors.Hand;
			borderEdges3.BottomLeft = true;
			borderEdges3.BottomRight = true;
			borderEdges3.TopLeft = true;
			borderEdges3.TopRight = true;
			this.btnSendAnswer.CustomizableEdges = borderEdges3;
			this.btnSendAnswer.DialogResult = System.Windows.Forms.DialogResult.None;
			this.btnSendAnswer.DisabledBorderColor = System.Drawing.Color.Empty;
			this.btnSendAnswer.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
			this.btnSendAnswer.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
			this.btnSendAnswer.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
			this.btnSendAnswer.Font = new System.Drawing.Font("Segoe UI Semibold", 13F);
			this.btnSendAnswer.ForeColor = System.Drawing.Color.White;
			this.btnSendAnswer.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
			this.btnSendAnswer.IconMarginLeft = 11;
			this.btnSendAnswer.IconPadding = 10;
			this.btnSendAnswer.IconRightCursor = System.Windows.Forms.Cursors.Hand;
			this.btnSendAnswer.IdleBorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnSendAnswer.IdleBorderRadius = 3;
			this.btnSendAnswer.IdleBorderThickness = 1;
			this.btnSendAnswer.IdleFillColor = System.Drawing.Color.CornflowerBlue;
			this.btnSendAnswer.IdleIconLeftImage = null;
			this.btnSendAnswer.IdleIconRightImage = null;
			this.btnSendAnswer.IndicateFocus = false;
			this.btnSendAnswer.Location = new System.Drawing.Point(757, 12);
			this.btnSendAnswer.Margin = new System.Windows.Forms.Padding(24, 12, 12, 12);
			this.btnSendAnswer.Name = "btnSendAnswer";
			stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
			stateProperties5.BorderRadius = 3;
			stateProperties5.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
			stateProperties5.BorderThickness = 1;
			stateProperties5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
			stateProperties5.ForeColor = System.Drawing.Color.White;
			stateProperties5.IconLeftImage = null;
			stateProperties5.IconRightImage = null;
			this.btnSendAnswer.onHoverState = stateProperties5;
			stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
			stateProperties6.BorderRadius = 3;
			stateProperties6.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
			stateProperties6.BorderThickness = 1;
			stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
			stateProperties6.ForeColor = System.Drawing.Color.White;
			stateProperties6.IconLeftImage = null;
			stateProperties6.IconRightImage = null;
			this.btnSendAnswer.OnPressedState = stateProperties6;
			this.btnSendAnswer.Size = new System.Drawing.Size(231, 78);
			this.btnSendAnswer.TabIndex = 0;
			this.btnSendAnswer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.btnSendAnswer.TextMarginLeft = 0;
			this.btnSendAnswer.UseDefaultRadiusAndThickness = true;
			this.btnSendAnswer.Click += new System.EventHandler(this.btnSendAnswer_Click);
			// 
			// btnAnswerA
			// 
			this.btnAnswerA.Active = false;
			this.btnAnswerA.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.btnAnswerA.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btnAnswerA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
			this.btnAnswerA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btnAnswerA.BorderRadius = 0;
			this.btnAnswerA.ButtonText = "AnswerA";
			this.btnAnswerA.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnAnswerA.DisabledColor = System.Drawing.Color.Gray;
			this.btnAnswerA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.btnAnswerA.Iconcolor = System.Drawing.Color.Transparent;
			this.btnAnswerA.Iconimage = null;
			this.btnAnswerA.Iconimage_right = null;
			this.btnAnswerA.Iconimage_right_Selected = null;
			this.btnAnswerA.Iconimage_Selected = null;
			this.btnAnswerA.IconMarginLeft = 0;
			this.btnAnswerA.IconMarginRight = 0;
			this.btnAnswerA.IconRightVisible = true;
			this.btnAnswerA.IconRightZoom = 0D;
			this.btnAnswerA.IconVisible = true;
			this.btnAnswerA.IconZoom = 90D;
			this.btnAnswerA.IsTab = false;
			this.btnAnswerA.Location = new System.Drawing.Point(264, 254);
			this.btnAnswerA.Margin = new System.Windows.Forms.Padding(0);
			this.btnAnswerA.Name = "btnAnswerA";
			this.btnAnswerA.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
			this.btnAnswerA.OnHovercolor = System.Drawing.Color.Gainsboro;
			this.btnAnswerA.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
			this.btnAnswerA.selected = false;
			this.btnAnswerA.Size = new System.Drawing.Size(724, 62);
			this.btnAnswerA.TabIndex = 3;
			this.btnAnswerA.Text = "AnswerA";
			this.btnAnswerA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnAnswerA.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.btnAnswerA.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAnswerA.Click += new System.EventHandler(this.btnAnswerA_Click);
			// 
			// txtQuestion
			// 
			this.txtQuestion.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.txtQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtQuestion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.txtQuestion.Location = new System.Drawing.Point(105, 78);
			this.txtQuestion.Name = "txtQuestion";
			this.txtQuestion.Size = new System.Drawing.Size(993, 158);
			this.txtQuestion.TabIndex = 4;
			this.txtQuestion.Text = "Cum procedați atunci când, circulând pe un drum public, la o curbă cu vizibilitat" +
    "e redusă sub 50 m, observați că în fața dumneavoastră se deplasează un vehicul c" +
    "u tracțiune animală?";
			this.txtQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblAnswerA
			// 
			this.lblAnswerA.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblAnswerA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
			this.lblAnswerA.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAnswerA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.lblAnswerA.Location = new System.Drawing.Point(201, 254);
			this.lblAnswerA.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
			this.lblAnswerA.Name = "lblAnswerA";
			this.lblAnswerA.Size = new System.Drawing.Size(63, 62);
			this.lblAnswerA.TabIndex = 5;
			this.lblAnswerA.Text = "A";
			this.lblAnswerA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblAnswerB
			// 
			this.lblAnswerB.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblAnswerB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
			this.lblAnswerB.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAnswerB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.lblAnswerB.Location = new System.Drawing.Point(201, 366);
			this.lblAnswerB.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
			this.lblAnswerB.Name = "lblAnswerB";
			this.lblAnswerB.Size = new System.Drawing.Size(63, 62);
			this.lblAnswerB.TabIndex = 7;
			this.lblAnswerB.Text = "B";
			this.lblAnswerB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnAnswerB
			// 
			this.btnAnswerB.Active = false;
			this.btnAnswerB.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.btnAnswerB.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btnAnswerB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
			this.btnAnswerB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btnAnswerB.BorderRadius = 0;
			this.btnAnswerB.ButtonText = "AnswerB";
			this.btnAnswerB.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnAnswerB.DisabledColor = System.Drawing.Color.Gray;
			this.btnAnswerB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.btnAnswerB.Iconcolor = System.Drawing.Color.Transparent;
			this.btnAnswerB.Iconimage = null;
			this.btnAnswerB.Iconimage_right = null;
			this.btnAnswerB.Iconimage_right_Selected = null;
			this.btnAnswerB.Iconimage_Selected = null;
			this.btnAnswerB.IconMarginLeft = 0;
			this.btnAnswerB.IconMarginRight = 0;
			this.btnAnswerB.IconRightVisible = true;
			this.btnAnswerB.IconRightZoom = 0D;
			this.btnAnswerB.IconVisible = true;
			this.btnAnswerB.IconZoom = 90D;
			this.btnAnswerB.IsTab = false;
			this.btnAnswerB.Location = new System.Drawing.Point(264, 366);
			this.btnAnswerB.Margin = new System.Windows.Forms.Padding(0, 50, 0, 50);
			this.btnAnswerB.Name = "btnAnswerB";
			this.btnAnswerB.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
			this.btnAnswerB.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
			this.btnAnswerB.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
			this.btnAnswerB.selected = false;
			this.btnAnswerB.Size = new System.Drawing.Size(724, 62);
			this.btnAnswerB.TabIndex = 6;
			this.btnAnswerB.Text = "AnswerB";
			this.btnAnswerB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnAnswerB.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.btnAnswerB.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAnswerB.Click += new System.EventHandler(this.btnAnswerB_Click);
			// 
			// lblAnswerC
			// 
			this.lblAnswerC.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblAnswerC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
			this.lblAnswerC.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAnswerC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.lblAnswerC.Location = new System.Drawing.Point(200, 478);
			this.lblAnswerC.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
			this.lblAnswerC.Name = "lblAnswerC";
			this.lblAnswerC.Size = new System.Drawing.Size(64, 62);
			this.lblAnswerC.TabIndex = 9;
			this.lblAnswerC.Text = "C";
			this.lblAnswerC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnAnswerC
			// 
			this.btnAnswerC.Active = false;
			this.btnAnswerC.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.btnAnswerC.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btnAnswerC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
			this.btnAnswerC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.btnAnswerC.BorderRadius = 0;
			this.btnAnswerC.ButtonText = "AnswerC";
			this.btnAnswerC.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnAnswerC.DisabledColor = System.Drawing.Color.Gray;
			this.btnAnswerC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.btnAnswerC.Iconcolor = System.Drawing.Color.Transparent;
			this.btnAnswerC.Iconimage = null;
			this.btnAnswerC.Iconimage_right = null;
			this.btnAnswerC.Iconimage_right_Selected = null;
			this.btnAnswerC.Iconimage_Selected = null;
			this.btnAnswerC.IconMarginLeft = 0;
			this.btnAnswerC.IconMarginRight = 0;
			this.btnAnswerC.IconRightVisible = true;
			this.btnAnswerC.IconRightZoom = 0D;
			this.btnAnswerC.IconVisible = true;
			this.btnAnswerC.IconZoom = 90D;
			this.btnAnswerC.IsTab = false;
			this.btnAnswerC.Location = new System.Drawing.Point(264, 478);
			this.btnAnswerC.Margin = new System.Windows.Forms.Padding(0);
			this.btnAnswerC.Name = "btnAnswerC";
			this.btnAnswerC.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
			this.btnAnswerC.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(225)))), ((int)(((byte)(225)))));
			this.btnAnswerC.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
			this.btnAnswerC.selected = false;
			this.btnAnswerC.Size = new System.Drawing.Size(724, 62);
			this.btnAnswerC.TabIndex = 8;
			this.btnAnswerC.Text = "AnswerC";
			this.btnAnswerC.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnAnswerC.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			this.btnAnswerC.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAnswerC.Click += new System.EventHandler(this.btnAnswerC_Click);
			// 
			// ucTest
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.WhiteSmoke;
			this.Controls.Add(this.lblAnswerC);
			this.Controls.Add(this.btnAnswerC);
			this.Controls.Add(this.lblAnswerB);
			this.Controls.Add(this.btnAnswerB);
			this.Controls.Add(this.txtQuestion);
			this.Controls.Add(this.btnAnswerA);
			this.Controls.Add(this.pnlTestBot);
			this.Controls.Add(this.pnlTestTop);
			this.Controls.Add(this.lblAnswerA);
			this.Name = "ucTest";
			this.Size = new System.Drawing.Size(1181, 705);
			this.pnlTestTop.ResumeLayout(false);
			this.pnlTestTop.PerformLayout();
			this.pnlTestBot.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel pnlTestTop;
		private System.Windows.Forms.Panel pnlTestBot;
		private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnQueueQuestion;
		private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnEraseAnswer;
		private System.Windows.Forms.Label lblTimer;
		private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnSendAnswer;
		private Bunifu.Framework.UI.BunifuFlatButton btnAnswerA;
		private System.Windows.Forms.Label txtQuestion;
		private System.Windows.Forms.Label lblAnswerA;
		private System.Windows.Forms.Label lblAnswerB;
		private Bunifu.Framework.UI.BunifuFlatButton btnAnswerB;
		private System.Windows.Forms.Label lblAnswerC;
		private Bunifu.Framework.UI.BunifuFlatButton btnAnswerC;
		private System.Windows.Forms.Label txtQuestionsLeftNumber;
		private System.Windows.Forms.Label txtQuestionsLeftText;
		private System.Windows.Forms.Label txtQuestionsTrueNumber;
		private System.Windows.Forms.Label txtQuestionsTrueText;
		private System.Windows.Forms.Label txtQuestionsFalseNumber;
		private System.Windows.Forms.Label txtQuestionsFalseText;
		private System.Windows.Forms.Label txtQuestionsTotalNumber;
		private System.Windows.Forms.Label txtQuestionsTotalText;
	}
}
